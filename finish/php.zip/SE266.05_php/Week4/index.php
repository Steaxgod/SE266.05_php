<?php
    header('Location: viewpations.php');
?>