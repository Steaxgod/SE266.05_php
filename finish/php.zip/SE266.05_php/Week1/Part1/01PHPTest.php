<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>SE 266 - Hello World</title>
    </head>
    <body>
		<h1>SE 266 - Hello World</h1>
       
       <?php
            echo "Welcome to PHP. PHP *really* rocks!";
        ?>
       
    </body>
</html>
