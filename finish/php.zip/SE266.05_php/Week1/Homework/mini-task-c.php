<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        
    </head>
    <body>
		<h1>SE 266 - Mini Task C</h1>
       
       <?php


            // Creating an Array

            $animals = 
            [
                "Lion",
                
                "Cat",
                
                "Dog",
                
                "Monkey"
            ];

            
            // Looping through the array and displaying it
            foreach ($animals as $animal){
                echo $animal . ', ';
            }
           
        ?>
       
    </body>
</html>
