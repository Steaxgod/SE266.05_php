<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
        <li><a href="../Homework\mini-task-c.php" target="_blank" id = "mini-task-c">mini-task-c </a></li>
   
        <li><a href="../Homework\mini-task-d.php" target="_blank" id = "mini-task-d">mini-task-d </a></li>

        <li><a href="..\Homework\mini-task-e.php" target="_blank" id = "mini-task-e">mini-task-e </a></li>

        <li><a href="..\Homework\mini-task-f.php" target="_blank" id = "mini-task-f">mini-task-f </a></li>

        <li><a href="..\Homework\mini-task-g.php" target="_blank" id = "mini-task-g">mini-task-g </a></li>

    </ul>

</body>
</html>