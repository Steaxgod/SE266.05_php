<?php
echo sha1 ("userSalt" . "duck");
?>