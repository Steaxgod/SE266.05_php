

    </div>
    <hr>
    <p></p>
    <div class="footer">&copy;2022 by Farid Steaxgod</div>
</body>
</html>